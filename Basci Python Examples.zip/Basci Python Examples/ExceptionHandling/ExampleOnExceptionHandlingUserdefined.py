class InvalidUserException(BaseException):#Code Reusability
	def __init__(self,message1):
   		super().__init__(message1)
     
username = input('Enter Username:')
password = input('Enter password:')

if username=='kpmg' and password=='india@123':
    print('welcome mr!  ',username)
else:
	raise InvalidUserException('invalid credentials')	

print("remaining statements")

