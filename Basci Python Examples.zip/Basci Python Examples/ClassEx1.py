class Test:
    def __init__(self):#constructor
        print("am from default constructor :")
    def m1(self):#instance method
        print("am from default function")

class Employee(Test): #constructor overloading not supported by python
    age=123#Data members and member functions
    def __init__(self):#constructor
        super().__init__()  # Call the parent constructor
        print("am from default constructor :")
    def welcomeMsg(self):#instance method
        print("am from default function")


emp=Employee()#object creation
emp.welcomeMsg()
emp.m1()
emp1=Employee()
