# import mymodule

# mymodule.f1()

import mymodule as a 
from mymodule import sayHello,age
from mymodule import * 

a.f1(" welcome to modules")
print(a.age)
print(dir(a))
print	